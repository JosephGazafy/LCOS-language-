
# LCOS-ICP Kubernetes Deployment

## Install

```bash
helm install lcos ./helm/lcos-icp
```

## Upgrade

```bash
helm upgrade lcos ./helm/lcos-icp
```

## Uninstall

```bash
helm uninstall lcos
```
